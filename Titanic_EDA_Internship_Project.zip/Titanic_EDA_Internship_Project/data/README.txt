The dataset CSV is downloaded here automatically the first time you run titanic_eda.py.
