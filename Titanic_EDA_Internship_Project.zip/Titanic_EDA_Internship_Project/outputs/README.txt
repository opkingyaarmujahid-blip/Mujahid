Run `python titanic_eda.py` to generate charts, CSV summaries, and analysis_report.md in this folder.
