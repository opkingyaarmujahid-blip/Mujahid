"""
Titanic Exploratory Data Analysis (EDA)
Internship Project 01

Run:
    pip install -r requirements.txt
    python titanic_eda.py

The script downloads the public Titanic dataset from the seaborn-data repository,
performs exploratory analysis, saves charts, and creates an analysis report.
Internet access is required for the first run.
"""
from pathlib import Path
import urllib.request
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "outputs"
DATA_DIR.mkdir(exist_ok=True)
OUT_DIR.mkdir(exist_ok=True)

DATA_URL = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv"
DATA_FILE = DATA_DIR / "titanic.csv"

def load_data():
    if not DATA_FILE.exists():
        print("Downloading Titanic dataset...")
        urllib.request.urlretrieve(DATA_URL, DATA_FILE)
    return pd.read_csv(DATA_FILE)

def main():
    df = load_data()

    # Basic inspection
    rows, cols = df.shape
    missing = df.isna().sum()
    survival_rate = df["survived"].mean() * 100
    class_survival = (df.groupby("class")["survived"].mean() * 100).round(2)
    sex_survival = (df.groupby("sex")["survived"].mean() * 100).round(2)
    age_summary = df["age"].describe()

    # Clean a working copy for analysis
    clean = df.copy()
    clean["age"] = clean["age"].fillna(clean["age"].median())
    clean["embarked"] = clean["embarked"].fillna(clean["embarked"].mode().iloc[0])
    clean["embark_town"] = clean["embark_town"].fillna(clean["embark_town"].mode().iloc[0])
    clean["deck"] = clean["deck"].fillna("Unknown")

    # 1. Survival count
    plt.figure(figsize=(7, 5))
    clean["survived"].value_counts().sort_index().plot(kind="bar")
    plt.title("Titanic: Survival Count")
    plt.xlabel("Survived (0 = No, 1 = Yes)")
    plt.ylabel("Number of passengers")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "survival_count.png", dpi=150)
    plt.close()

    # 2. Survival by passenger class
    plt.figure(figsize=(7, 5))
    (clean.groupby("class")["survived"].mean() * 100).plot(kind="bar")
    plt.title("Survival Rate by Passenger Class")
    plt.xlabel("Passenger class")
    plt.ylabel("Survival rate (%)")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "survival_by_class.png", dpi=150)
    plt.close()

    # 3. Survival by sex
    plt.figure(figsize=(7, 5))
    (clean.groupby("sex")["survived"].mean() * 100).plot(kind="bar")
    plt.title("Survival Rate by Sex")
    plt.xlabel("Sex")
    plt.ylabel("Survival rate (%)")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "survival_by_sex.png", dpi=150)
    plt.close()

    # 4. Age distribution
    plt.figure(figsize=(8, 5))
    clean["age"].plot(kind="hist", bins=25, edgecolor="black")
    plt.title("Passenger Age Distribution")
    plt.xlabel("Age")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "age_distribution.png", dpi=150)
    plt.close()

    # 5. Fare distribution
    plt.figure(figsize=(8, 5))
    clean["fare"].plot(kind="hist", bins=30, edgecolor="black")
    plt.title("Passenger Fare Distribution")
    plt.xlabel("Fare")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "fare_distribution.png", dpi=150)
    plt.close()

    report = [
        "# Titanic Exploratory Data Analysis Report",
        "",
        "## 1. Project objective",
        "Explore the Titanic passenger dataset with Python and Pandas to understand passenger characteristics and survival patterns.",
        "",
        "## 2. Dataset overview",
        f"- Rows: {rows}",
        f"- Columns: {cols}",
        f"- Overall survival rate: {survival_rate:.2f}%",
        "",
        "## 3. Missing values",
        missing.to_frame("Missing values").to_markdown(),
        "",
        "## 4. Survival rate by passenger class",
        class_survival.to_frame("Survival rate (%)").to_markdown(),
        "",
        "## 5. Survival rate by sex",
        sex_survival.to_frame("Survival rate (%)").to_markdown(),
        "",
        "## 6. Age summary",
        age_summary.to_frame("Age").to_markdown(),
        "",
        "## 7. Data preparation",
        "- Filled missing age values with the median age.",
        "- Filled missing embarkation values with the most frequent value.",
        "- Replaced missing deck values with `Unknown` for analysis.",
        "",
        "## 8. Visualizations",
        "- `survival_count.png`",
        "- `survival_by_class.png`",
        "- `survival_by_sex.png`",
        "- `age_distribution.png`",
        "- `fare_distribution.png`",
        "",
        "## 9. Conclusion",
        f"The dataset contains {rows} passenger records. The overall survival rate is {survival_rate:.2f}%.",
        "The class-wise and sex-wise tables above help compare survival outcomes across passenger groups.",
        "These are descriptive patterns in this dataset and do not by themselves prove causation.",
        "",
        "## 10. Tools used",
        "Python, Pandas, Matplotlib",
        "",
        "## Reproducibility",
        "Run `python titanic_eda.py` to recreate the charts and this report. The script downloads the dataset on its first run."
    ]
    (OUT_DIR / "analysis_report.md").write_text("\n".join(report), encoding="utf-8")
    clean.describe(include="all").to_csv(OUT_DIR / "descriptive_statistics.csv")
    missing.to_csv(OUT_DIR / "missing_values.csv", header=["missing_count"])

    print("Analysis complete!")
    print(f"Dataset shape: {rows} rows x {cols} columns")
    print(f"Overall survival rate: {survival_rate:.2f}%")
    print(f"Charts and report saved in: {OUT_DIR}")

if __name__ == "__main__":
    main()
