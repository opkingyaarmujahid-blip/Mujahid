# Titanic Exploratory Data Analysis (EDA)

**Internship Project 01**

## Objective
Explore the Titanic passenger dataset using Python and Pandas. The project examines missing values, passenger demographics, fares, passenger class, and survival patterns.

## Project files
- `titanic_eda.py` — complete analysis script
- `requirements.txt` — required Python libraries
- `data/` — downloaded dataset is stored here after the first run
- `outputs/` — charts, CSV summaries, and the generated report are saved here

## How to run
1. Install Python 3.9 or newer.
2. Open a terminal in this project folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python titanic_eda.py
   ```

The script downloads the public Titanic CSV dataset the first time it runs, so an internet connection is required for the first run.

## Questions explored
- How many passenger records and columns are in the dataset?
- Which columns contain missing values?
- How does survival rate vary by passenger class?
- How does survival rate vary by sex?
- What do passenger age and fare distributions look like?

## Data source
Seaborn's public `titanic.csv` dataset:
https://github.com/mwaskom/seaborn-data/blob/master/titanic.csv

## Important note
This is a descriptive exploratory analysis. Observed associations do not prove that one factor caused survival.
